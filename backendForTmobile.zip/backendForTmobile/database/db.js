module.exports = {
   db: 'mongodb://192.168.10.105:27017/testresults'
};