export const environment = {
  production: true,
  hmr: false,
  backend: true
};
