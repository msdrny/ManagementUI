export const environment = {
  production: false,
  hmr: false,
  backend: true
};
