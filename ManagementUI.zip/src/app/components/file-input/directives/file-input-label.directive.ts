import { Directive } from '@angular/core';

@Directive({
  selector: 'file-input-label'
})
export class FileInputLabelDirective { }

