import { Directive } from '@angular/core';

@Directive({
  selector: 'file-input-hint'
})
export class FileInputHintDirective { }

