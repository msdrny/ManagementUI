import { NgModule } from '@angular/core';

import { SkyconComponent } from './skycon.component';

@NgModule({
  declarations: [
    SkyconComponent
  ],
  exports: [
    SkyconComponent
  ]
})
export class SkyconsModule {
}
