export type WidgesterTooltipPosition = 'top' | 'right' | 'bottom' | 'left' | 'auto';
