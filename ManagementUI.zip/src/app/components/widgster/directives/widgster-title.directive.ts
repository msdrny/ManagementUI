import { Directive } from '@angular/core';

@Directive({ selector: '[widgsterTitle]' })
export class WidgsterTitleDirective { }
