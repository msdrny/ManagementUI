import { Directive } from '@angular/core';

@Directive({ selector: '[widgsterFooter]' })
export class WidgsterFooterDirective { }
