import { Directive } from '@angular/core';

@Directive({ selector: '[widgsterControls]' })
export class WidgsterControlsDirective { }
