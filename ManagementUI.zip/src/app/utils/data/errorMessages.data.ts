export const ErrorMessages={
    SHOW_LIST_ERROR:"There is a failure when getting test reports list from server",
    SHOW_FILE_ERROR:"There is a failure when getting test report from server",
    DOWNLOAD_FILE_ERROR:"There is a failure when downloading test report from server",
    UPLOAD_FILE_ERROR:"There is a failure when uploading test report from server"

}