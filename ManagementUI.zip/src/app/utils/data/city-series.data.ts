export const citySeries = [
  {
    latitude: 47.654354,
    longitude: -122.0819397,
    size: 6,
    tooltip: 'Redmond'
  }
];
