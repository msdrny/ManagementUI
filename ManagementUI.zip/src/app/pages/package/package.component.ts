import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'package',
  templateUrl: './package.template.html',
  styleUrls: [
    './package.style.scss'
  ],
  encapsulation: ViewEncapsulation.None
})
export class Package {

  
}
