import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: '[extra-time-line]',
  templateUrl: './time-line.template.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./time-line.style.scss']
})
export class TimeLineComponent {
}
