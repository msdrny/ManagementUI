import { NgOption } from "@ng-select/ng-select";

export const colors: NgOption[] =[
    { id: 1, name: 'white' },
    { id: 2, name: 'red' },
    { id: 3, name: 'green' },
    { id: 4, name: 'black' },
    { id: 5, name: 'orange' },
    { id: 6, name: 'purple' }
  ]

  export const url: string[] =[
"192.168.10.110",
"192.168.10.120",
"192.168.10.130",
"192.168.10.140",
"192.168.10.150",
"192.168.10.160",
"192.168.10.170",
"192.168.10.180",
"192.168.10.190",
"192.168.10.210",
"192.168.10.220",
"192.168.10.230",
"192.168.10.240"
  ]