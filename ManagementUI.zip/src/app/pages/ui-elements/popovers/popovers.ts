import {Component} from '@angular/core';

@Component({
  selector: 'popovers',
  templateUrl: './popovers.html'
})
export class PopoversComponent {
}
