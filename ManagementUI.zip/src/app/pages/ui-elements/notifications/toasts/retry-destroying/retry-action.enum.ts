export enum RetryAction {
  retry,
  cancel
}
