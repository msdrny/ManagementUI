import {Component} from '@angular/core';

@Component({
  selector: 'progress-page',
  templateUrl: './progress.html'
})
export class ProgressComponent {
}
