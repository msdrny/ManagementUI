import {Component} from '@angular/core';

@Component({
  selector: 'modal-page',
  templateUrl: './modal.html'
})
export class ModalComponent {
}
