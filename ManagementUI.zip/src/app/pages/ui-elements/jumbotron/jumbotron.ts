import {Component} from '@angular/core';

@Component({
  selector: 'jumbotron',
  templateUrl: './jumbotron.html'
})
export class JumbotronComponent {
}
