import {Component} from '@angular/core';

@Component({
  selector: 'badge',
  templateUrl: './badge.html'
})
export class BadgeComponent {
}
