import {Component} from '@angular/core';

@Component({
  selector: 'card',
  templateUrl: './card.html'
})
export class CardComponent {
}
