export interface MaximumConnection {
  id: String;
  startTime: Number;
  endTime: Number;
}
