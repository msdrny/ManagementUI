export interface EigCqi {
  testid:String
  date:Date
  cwi0:Number
  cwi1:Number
}





