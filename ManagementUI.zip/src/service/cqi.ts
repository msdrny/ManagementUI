export interface Cqi {
  time:Date
  cqi:Number
}