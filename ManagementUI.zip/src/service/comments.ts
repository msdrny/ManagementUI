export interface Comments {
  comment:String
  insertDate:String
  date:Date
}


