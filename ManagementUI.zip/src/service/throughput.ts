export interface Throughput {
  id:String,
  time:number, 
  l1w0:number, 
  l1w1:number, 
  l1w2:number, 
  l1w3:number, 
  l1w4:number, 
  l1w5:number, 
  l1w6:number, 
  l1w7:number, 
  l2w0:number, 
  l2w1:number, 
  l2w2:number, 
  l2w3:number, 
  l2w4:number, 
  l2w5:number, 
  l2w6:number, 
  l2w7:number,
  l3w0:number, 
  l3w1:number, 
  l3w2:number, 
  l3w3:number, 
  l3w4:number, 
  l3w5:number, 
  l3w6:number, 
  l3w7:number, 
  connectedClients :number
   


}
