import { TimeForThroughput } from './TimeForThroughput';

export interface AgregatedSum {
  _id:TimeForThroughput
  total:Number
}