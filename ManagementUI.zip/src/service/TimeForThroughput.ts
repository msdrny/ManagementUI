export interface TimeForThroughput {
  time:Date
}