export interface EigAcs {
  testid:String
  time:Date
  rsrp:Number
  rsrq :Number
  band:Number
  bandwith:Number
  rssi :Number
  cqi:Number
  cellId:Number
}





