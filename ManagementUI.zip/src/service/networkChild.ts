export interface NetworkChild {
     pci  :Number,
     rssi :Number,
     rsrp :Number,
     rsrq :Number,
     sinr :Number,
     srxlev :Number,
     band :Number,
     bandw :Number,
     rxch :Number,
     txch :Number,
     cid :Number,
     sband :Number,
     sbw :Number,
     sch :Number
}
