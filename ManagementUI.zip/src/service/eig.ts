export interface Eig {
  testid:String
  date:Date
  cellId:String
  rsrp:Number
  fltRsrp:Number
  rsrq :Number
  fltRsrq:Number
  instRSSI :Number
}





