export interface Inventory {
    host: String;
    usage: number;
    duration: number;
    time: Date;
    port:number;
  }