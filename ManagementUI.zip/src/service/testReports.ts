export interface TestReport {
    name: String;
    url: String;
    view: String;
    date: Date;
    sortDate:Date
  }