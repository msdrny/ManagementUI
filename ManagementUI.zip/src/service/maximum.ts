export interface Maximum {
  id: String;
  brand: String;
  clientCounts: number;
  connectedClients: number;
  disconnectedClients: number;
}
