import { NetworkChild } from './networkChild';

export interface Network {
 data:NetworkChild[]
}
