export interface Rsrp {
  time:Date
  rsrp:Number
}