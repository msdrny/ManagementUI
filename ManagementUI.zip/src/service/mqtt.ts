import { Network } from './network';

export interface Mqtt {
  Status: String;
  ModuleCommand: String;
  Result:Network
  time: Date;
}

