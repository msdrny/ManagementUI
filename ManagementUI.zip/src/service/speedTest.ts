export interface SpeedTest {
    time:Date
    usage:number
  }