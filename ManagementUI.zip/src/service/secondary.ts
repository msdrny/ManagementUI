export interface Secondary {
    testid:String;
    host: String;
    usage: number;
    duration: number;
    date: Date;
    port:number;
    
  }

  