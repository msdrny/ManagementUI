export interface Rsrq {
  time:Date
  rsrq:Number
}