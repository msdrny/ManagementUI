export interface TestMetadata {
    id: String;
    hardware_version: String;
    software_version: String;
    start_time: String;
    estimated_end_time: String;
    end_time: String;
    test_name: String;
    test_name_short: String;

  }


  
